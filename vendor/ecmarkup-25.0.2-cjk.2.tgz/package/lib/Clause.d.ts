import type Spec from './Spec';
import type { Signature, ParsedParams } from './Biblio';
import type { Context } from './Context';
import Builder from './Builder';
import type { ParsedHeader } from './header-parser';
export declare const SPECIAL_KINDS_MAP: Map<string, string>;
export declare const SPECIAL_KINDS: string[];
export declare const VALID_BUILTIN_NAME_REGEX: RegExp;
export declare function getHeaderSource(header: Element, spec: Spec): string;
export declare function extractStructuredHeader(header: Element): Element | null;
export default class Clause extends Builder {
    isAnnex: boolean;
    isBackMatter: boolean;
    isNormative: boolean;
    constructor(spec: Spec, node: HTMLElement, parent: Clause, number: string);
    canHaveEffect(effectName: string): boolean;
    static enter({ spec, node, clauseStack, clauseNumberer }: Context): Promise<void>;
    static exit({ node, spec, clauseStack, inAlg, currentId }: Context): void;
    getSecnumHTML(): string;
    static elements: string[];
    static linkElements: string[];
}
export declare function parsedHeaderToSignature(parsedHeader: ParsedHeader): Signature;
export declare function parseParams(params: string): ParsedParams | null;
//# sourceMappingURL=Clause.d.ts.map