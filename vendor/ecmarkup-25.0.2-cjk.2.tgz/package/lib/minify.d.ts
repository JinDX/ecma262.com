type GeneratedFiles = Map<string | null, string | Buffer>;
type Log = (str: string) => void;
export declare function minifyGeneratedFiles(files: GeneratedFiles, log?: Log): Promise<GeneratedFiles>;
export {};
//# sourceMappingURL=minify.d.ts.map