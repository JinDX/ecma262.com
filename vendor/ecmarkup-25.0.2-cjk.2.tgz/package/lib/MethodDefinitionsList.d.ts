import type Spec from './Spec';
import type { Context } from './Context';
import Builder from './Builder';
import type Clause from './Clause';
export default class MethodDefinitionsList extends Builder {
    static readonly elements: readonly ["EMU-CONCRETE-METHOD-DFNS", "EMU-INTERNAL-METHOD-DFNS"];
    private _for;
    private _parentClause;
    constructor(spec: Spec, node: HTMLElement, _for: string, parentClause: Clause);
    static enter({ node, spec, clauseStack }: Context): Promise<void>;
    build(): void;
}
//# sourceMappingURL=MethodDefinitionsList.d.ts.map