import type Spec from './Spec';
import type { Context } from './Context';
import type { Signature } from './Biblio';
import Figure from './Figure';
type MethodsTableType = 'abstract methods' | 'internal methods';
export default class Table extends Figure {
    table: HTMLTableElement;
    tableType: null | MethodsTableType;
    methods: Map<string, {
        signature: Signature;
        rowId: string | undefined;
    }>;
    of: string | null;
    static elements: string[];
    constructor(spec: Spec, node: HTMLElement, table: HTMLTableElement, tableType: null | MethodsTableType);
    private processMethodsDeclarations;
    defineInnerBiblioEntries(): void;
    static enter({ spec, node }: Context): Promise<void>;
}
export {};
//# sourceMappingURL=Table.d.ts.map