import type Spec from './Spec';
import type { JSDOM } from 'jsdom';
export type Import = {
    importLocation: string;
    relativeRoot: string;
    source: string;
};
export declare function buildImports(spec: Spec, importNode: EmuImportElement, root: string): Promise<void>;
export interface EmuImportElement extends HTMLElement {
    href: string;
    dom: JSDOM;
    source?: string;
    importPath?: string;
}
//# sourceMappingURL=Import.d.ts.map