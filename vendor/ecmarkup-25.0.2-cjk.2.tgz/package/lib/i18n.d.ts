export type Locale = 'en' | 'zh' | 'ja' | 'ko';
type Context = {
    doc: Document;
};
export declare function locale(spec: Context): Locale;
export declare function t(spec: Context, key: string): string;
export declare function pick(spec: Context, en: string, zh: string, ja: string, ko: string): string;
export declare function joinList(spec: Context, items: string[], conjunction?: string): string;
export declare function operationLead(spec: Context, kind: string, name: string, term?: (original: string, translated: string) => string): string;
export declare function operationSignature(spec: Context, params: string, returns: string | null): string;
export declare function clientI18n(spec: Context): string;
export {};
//# sourceMappingURL=i18n.d.ts.map