import type Spec from './Spec';
export declare function typecheck(spec: Spec): void;
//# sourceMappingURL=typechecker.d.ts.map