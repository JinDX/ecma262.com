import type Spec from './Spec';
import type { TermFormatter } from './term-display';
export declare function displayType(spec: Spec, input: string, term?: TermFormatter): string;
//# sourceMappingURL=type-display.d.ts.map