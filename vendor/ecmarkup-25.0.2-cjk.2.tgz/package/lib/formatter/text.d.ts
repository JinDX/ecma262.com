import { LineBuilder } from './line-builder';
export declare function printText(text: string, indent: number, commonIndent?: string): LineBuilder;
//# sourceMappingURL=text.d.ts.map