import type Biblio from './Biblio';
import type { Type as BiblioType } from './Biblio';
import type { Expr, NonSeq } from './expr-parser';
export type Type = {
    kind: 'unknown';
} | {
    kind: 'never';
} | {
    kind: 'union';
    of: NonUnion[];
} | {
    kind: 'list';
    of: Type;
} | {
    kind: 'record';
} | {
    kind: 'normal completion';
    of: Type;
} | {
    kind: 'abrupt completion';
} | {
    kind: 'real';
} | {
    kind: 'integer';
} | {
    kind: 'non-negative integer';
} | {
    kind: 'negative integer';
} | {
    kind: 'positive integer';
} | {
    kind: 'concrete real';
    value: string;
} | {
    kind: 'ES value';
} | {
    kind: 'object';
} | {
    kind: 'function';
} | {
    kind: 'string';
} | {
    kind: 'number';
} | {
    kind: 'integral number';
} | {
    kind: 'bigint';
} | {
    kind: 'boolean';
} | {
    kind: 'null';
} | {
    kind: 'undefined';
} | {
    kind: 'concrete string';
    value: string;
} | {
    kind: 'concrete number';
    value: number;
} | {
    kind: 'concrete bigint';
    value: bigint;
} | {
    kind: 'concrete boolean';
    value: boolean;
} | {
    kind: 'enum value';
    value: string;
};
type NonUnion = Exclude<Type, {
    kind: 'union';
}>;
export declare function dominates(a: Type, b: Type): boolean;
export declare function join(a: Type, b: Type): Type;
export declare function meet(a: Type, b: Type): Type;
export declare function serialize(type: Type): string;
export declare function typeFromExpr(expr: Expr, biblio: Biblio, warn: (offset: number, message: string) => void): Type;
export declare function typeFromExprType(type: BiblioType): Type;
export declare function isCompletion(type: Type): type is Type & {
    kind: 'normal completion' | 'abrupt completion' | 'union';
};
export declare function isPossiblyAbruptCompletion(type: Type): type is Type & {
    kind: 'abrupt completion' | 'union';
};
export declare function stripWhitespace(items: NonSeq[]): NonSeq[];
export {};
//# sourceMappingURL=type-logic.d.ts.map