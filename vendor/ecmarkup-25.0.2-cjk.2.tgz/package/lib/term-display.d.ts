import type Spec from './Spec';
export type TermFormatter = (original: string, translated: string) => string;
export declare function generatedTerm(spec: Spec, original: string, translated: string): string;
export declare function bindGeneratedTerms(spec: Spec, preamble: Element): void;
export declare function linkGeneratedTerms(spec: Spec): void;
//# sourceMappingURL=term-display.d.ts.map