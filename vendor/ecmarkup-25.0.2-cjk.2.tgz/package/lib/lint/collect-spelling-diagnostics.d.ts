import type { Warning } from '../Spec';
import type { Import } from '../Import';
export declare function collectSpellingDiagnostics(report: (e: Warning) => void, mainSource: string, imports: Import[]): void;
//# sourceMappingURL=collect-spelling-diagnostics.d.ts.map