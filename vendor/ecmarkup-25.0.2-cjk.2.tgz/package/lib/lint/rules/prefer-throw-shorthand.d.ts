import type { Reporter } from '../algorithm-error-reporter-type';
import type { OrderedListItemNode } from 'ecmarkdown';
import type { Seq } from '../../expr-parser';
export default function (report: Reporter, step: OrderedListItemNode, algorithmSource: string, parsedSteps: Map<OrderedListItemNode, Seq>): void;
//# sourceMappingURL=prefer-throw-shorthand.d.ts.map