import type Spec from './Spec';
export declare function displayType(spec: Spec, input: string): string;
//# sourceMappingURL=type-display.d.ts.map